import json

def lambda_handler(event, context):
    # TODO implement
    # print(event)
    # http_method = event["httpMethod"]
    
    # result = ""
    # if http_method == "GET":
    # 	result = "Hello from "+event["queryStringParameters"]["name"]
    # elif http_method == "POST" :
    # 	body = json.loads(event["body"])
    # 	result = "Hello from "+body["name"]
    
    return {
        'statusCode': 200,
        'body' : json.dumps("Hello world")
        # 'body': json.dumps(result)
    }